﻿namespace CRMApp
{
    public class Order
    {
        public string ClientName { get; set; }
        public string ServiceName { get; set; }
        public string Status { get; set; }
    }
}